<template>
  <div class="product-path">
    <Header/>
    <div class="main-body">
      <div class="sidebar">
        <SidebarMenu/>
      </div>
      <ProductInfo :product="product" :profile="profile"/>
    </div>

    <Footer></Footer>

    <div class="notification-container">
      <div class="notif" v-for="notification of getUnreadNotifications">
        <Notification v-if="notification.status == 1" :notificationContent="notification.data.text" :notification-from="notification.data.from.name" :click-event="showMessages" :close-event="hideNotification" :id="notification.notification_id" />
      </div>

    </div>
  </div>


</template>

<script>
// @ is an alias to /sr
import Header from "@/components/Header";
import SidebarMenu from "@/components/Sidebar/SidebarMenu";
import Footer from "@/components/Footer.vue";
import Notification from "@/components/Notification";
import ApiWrapper from "../api";
import {mapGetters, mapMutations} from "vuex";
import ProductInfo from "@/components/ProductInfo.vue";
import SubscriptionsSection from "@/components/SubscriptionsSection.vue";
const {useToast, POSITION, TYPE} = require('vue-toastification');
export default {
  name: "HomeView",
  components: {
    Header,
    SidebarMenu,
    Notification,
    Footer,
    ProductInfo
  },
  data() {
    return {
      productId: '',
      profile: {
        mail: '',
        name: '',
        phone: '',
        img: '',
        isLogin: false
      },
      product: {
      },
      showNotification: true,
      contentNotification: {
        show: localStorage.getItem('welcome-notification') != 'true',
        title: 'Новое сообщение',
        messageFrom: 'Neearby.com',
        message: 'Алекс Жаркий, поздравляем! Теперь Вы сможете продав...',
        button: {
          label: 'Посмотреть',
          clickEvent: () => {
              this.showNotification = false;
              localStorage.setItem('welcome-notification', 'true');
          }
        }
      },
    }
  },
  methods: {
    ...mapMutations(['setCurrentProile']),


  },

  computed: {
    ...mapGetters(['getCurrentProfile', 'getAuthorizedProfile', 'getUnreadNotifications'])
  },

  async mounted() {
    const toast = useToast();
    this.productId = window.location.pathname.split('/')[window.location.pathname.split('/').length - 1];
    this.profile.mail =  this.getAuthorizedProfile.email;
    this.profile.name =  this.getAuthorizedProfile.name;
    this.profile.phone =  this.getAuthorizedProfile.phone;
    await ApiWrapper.getProfile({login: this.getAuthorizedProfile.login}).then(response => {
      this.profile.img = response.data.profile_path;
    });
    await ApiWrapper.getProduct({ids: [this.productId]}).then(response => {
      if(!response.success || response.data.length < 1){
        toast('Неверная ссылка на товар, данного товара не существует или он был удален', {position: POSITION.BOTTOM_RIGHT, type: TYPE.ERROR});
        return this.$router.push(`/`);
      }
      this.product = response.data[0];
    });


  }
};
</script>

<style lang="scss">

body {
  margin: 0 !important;
}

.home {
  height: 100vh;
  background-color: #EDEEF0;

  .notification-container {
    position: fixed;
    display: flex;
    flex-direction: column;
    bottom: 0;  
    height: 9rem;
    width: 18%;
    overflow: hidden;
    padding: 1%;
  }

  .disable {
    display: none;
  }
}



.main-body {
  display: grid;
  grid-template-columns: 2fr 3fr 15fr 3fr ;
  background-color: var(--secondary-color);
  padding-bottom: 20px;
}

.sidebar {
  grid-column: 2 / 3;
}

.author-content {
  grid-column: 3 / 4;
  display: grid;
  grid-template-columns: 3.5fr 1fr;

  .full-width {
    grid-column: 1 / 3;
  }

  .posts-and-products {
    grid-column: 1 / 2;
  }

  .subscriptions {
    margin-left: 15px;
    width: calc(100% - 15px);
    display: flex;
    flex-direction: column;
    grid-column: 2 / 3;

    .add-subscription-button{
      margin-top: 15px;
    }
  }

  @media (max-width: 1250px) {
    .posts-and-products {
      grid-column: 1 / 3;
    }

    .subscriptions{
      grid-column: 1 / 3;
      margin-left: 0;
      width: 100%;
    }

    .main-body {
      grid-template-columns: 1fr 3fr 15fr 1fr ;
    }


  }

}
.product-card{
  width: 95%;
  margin: 15px auto;
}
</style>
