<template>
    <div>
        <select>
            <option value=""> Инфобизнес </option>
        </select>
    </div>
</template>


<style lang="scss" scoped>

select {
    transition: 0.2s ease-out all;
    background: white;
    outline: none;
    border: 1px solid #A8ADB8;
    border-radius: 10px ;   
    height: 2.3rem;
    width: 98.5%;
    text-indent: 20px;
    margin-top: 20px;
    background-image: url('../assets/arrows.svg');
    background-size: 1rem;
    background-repeat: no-repeat;
    background-position: 98%;
    appearance: none;

}
</style>